﻿using final_project.Classes;
using final_project.Database;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace final_project.Page
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class login
    {
        public login()
        {
            this.InitializeComponent();
            if (SessionManager.IsUserLoggedIn)
                Frame.Navigate(typeof(AccountHome));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(registration));
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                string email = UsernameTextBox.Text.Trim();
                string password = PasswordBox.Password.Trim();
                string query = $"SELECT * FROM UserProfile WHERE email = '{email}' AND [password] = '{password}'";
                int result = User.ConvertDataTableUserList(new DatabaseAccess().SelectData(query)).Count();

                if (result != 0)
                {
                    SessionManager.CurrentUser = SessionManager.getUserByEmail(email);
                    await new ContentDialog1("Successfully logged in").ShowAsync();
                    Frame.Navigate(typeof(AccountHome));
                }
                else
                {
                    await new ContentDialog1("Invalid login credentials").ShowAsync();
                }
            }
            catch (Exception ex)
            {
                await new ContentDialog1(ex.Message).ShowAsync();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(index));
        }
    }
}
