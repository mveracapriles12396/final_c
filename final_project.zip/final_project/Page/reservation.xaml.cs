﻿using final_project.Classes;
using final_project.Database;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace final_project.Page
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class reservation
    {
        public Theatre theatre { get; set; }
        public Movie movie { get; set; }
        
        public Show show { get; set; }
        
        User user;
        decimal price;
        int user_id;
        public TicketPrice ticketPrice { get; set; }

        DatabaseAccess dt = new DatabaseAccess();

        public reservation()
        {
            this.InitializeComponent();
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            if (e.Parameter is Show show)
            {
                this.show = show;
                string query = "SELECT * FROM Movie where movie_id =" + show.movie_id + ";";
                string query2 = "SELECT * FROM Theatre where location_id =" + show.location_id + ";";
                string query3 = "SELECT * FROM TicketPrice where location_id =" + show.location_id + ";";
                movie = Movie.ConvertDataTableToMoviesList(dt.SelectData(query)).Last();
                theatre = Theatre.ConvertDataTableToTheatresList(dt.SelectData(query2)).Last();
                ticketPrice = TicketPrice.ConvertDataTableTicketPriceList(dt.SelectData(query3)).Last();
                if (SessionManager.IsUserLoggedIn)
                {
                    user = SessionManager.CurrentUser;
                    txtUser.Text = user.email;
                    user_id = user.user_id;
                    guest_login.Visibility = Visibility.Collapsed;
                    if (user.date_of_birth.Year < 1959)
                        price = ticketPrice.senior_discount;
                    if (user.is_student)
                        price = ticketPrice.student_discount;
                    if (user.user_id == 1)
                        price = ticketPrice.admin_discount;
                    if (user.user_id == 2)
                        price = ticketPrice.member_discount;
                }
                else
                {
                    txtUser.Text = "Guest";
                    user_id = 2;
                    guest_login.Visibility = Visibility.Visible;
                    price = ticketPrice.regular_price;
                }
            }
        }
        private void btnCreateTicket_Click(object sender, RoutedEventArgs e)
        {
            int quantity = 0;
            try
            {
                if (int.TryParse(txtQuantity.Text, out quantity) && quantity > 0 && quantity <= show.available_seats)
                {
                    decimal totalPrice = quantity * ticketPrice.regular_price;
                    string orderDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    string createTicket = $@"INSERT INTO Ticket (user_id, show_id, quantity, price, order_date, amount) VALUES
                                ({user_id}, {show.show_id}, {quantity}, {price}, '{orderDate}', {totalPrice})";
                    dt.insertData(createTicket);
                    int seats = show.available_seats - quantity;
                    string updateQuantity = "UPDATE Show SET available_seats ="+seats+"WHERE show_id ="+show.show_id;
                    dt.updateData(updateQuantity);
                    creationTicketResult("Ticket Created");
                    Frame.Navigate(typeof(index));
                }
                else
                {
                    creationTicketResult("Invalid quantity");
                }
            }
            catch (Exception ex)
            {
                creationTicketResult(ex.Message);
            }
            
        }
        private void txtQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (int.TryParse(txtQuantity.Text, out int quantity) && quantity >= 0)
            {
                decimal price = ticketPrice.regular_price;
                decimal totalAmount = price * quantity;
                txtTotalAmount.Text = totalAmount.ToString();
            }
            else
            {
                txtTotalAmount.Text = "Invalid Quantity";
            }
        }

        private async void creationTicketResult(string dialogContent)
        {
            ContentDialog dialog = new ContentDialog
            {
                Title = "Result",
                Content = dialogContent,
                CloseButtonText = "CLOSE"
            };

            await dialog.ShowAsync();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof (login));
        }
    }
}
