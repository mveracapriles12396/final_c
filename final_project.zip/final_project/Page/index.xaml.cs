﻿using final_project.Classes;
using final_project.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Data.SqlClient;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Threading.Tasks;
using System.Diagnostics;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace final_project.Page
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class index 
    {
        
        DatabaseAccess data = new DatabaseAccess();
        public List<Movie> MoviesList { get; set; }
        public List<Theatre> TheatresList { get; set; }

        public index()
        {
                // getting the data
                DataTable movies =  data.SelectData("SELECT * FROM Movie;");
                DataTable theatres = data.SelectData("SELECT * FROM Theatre;");
                // setting the list
                this.MoviesList = Movie.ConvertDataTableToMoviesList(movies);
                this.TheatresList = Theatre.ConvertDataTableToTheatresList(theatres);
                // initializeComponent
                this.InitializeComponent();
                // implement the list view
                movieListView.ItemsSource = this.MoviesList;
                theatreListView.ItemsSource = this.TheatresList;
        }
        private void moviesListView_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (e.ClickedItem is Movie selectedMovie)
            {
                Frame.Navigate(typeof(shows), selectedMovie);
            }
        }
        private async void theatreListView_ItemClick(object sender, ItemClickEventArgs e)
        {
            if (e.ClickedItem is Theatre selectedTheatre)
            {
                // Create your dialog content here using the selectedTheatre object
                string dialogContent = $"Theater Name: {selectedTheatre.location_name}\n" +
                                       $"Address: {selectedTheatre.location_address}\n" +
                                       $"Phone Number: {selectedTheatre.location_phone}\n" +
                                       $"Opening Hours: {selectedTheatre.business_hours}\n";

                ContentDialog dialog = new ContentDialog
                {
                    Title = "Theater Information",
                    Content = dialogContent,
                    CloseButtonText = "CLOSE"
                };

                await dialog.ShowAsync();
            }
        }

    }
}
