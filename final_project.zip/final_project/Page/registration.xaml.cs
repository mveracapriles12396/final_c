﻿using final_project.Classes;
using final_project.Database;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace final_project.Page
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class registration 
    {
        public List<UserType> userTypes { get; set; }
        DatabaseAccess dt = new DatabaseAccess();
        public registration()
        {
            this.InitializeComponent();
            LoadUserTypes();
        }

        public  void LoadUserTypes()
        {
            string query = "SELECT * FROM UserType;"; 
            userTypes = UserType.ConvertDataTableUserTypeList(dt.SelectData(query));

        }
        private bool CheckIfUserExist(string email)
        {
            try
            {
                bool result = false;
                string query = $"SELECT TOP 1 * FROM UserProfile WHERE email = '{email}'";
                User user = User.ConvertDataTableUserList(dt.SelectData(query)).FirstOrDefault(); 
                if (user != null)
                {
                    result = true;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private async void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string email = EmailTextBox.Text.Trim();
                string password = PasswordBox.Password.Trim();
                DateTime dateOfBirth = DatePicker.Date.DateTime;
                bool isStudent = IsStudentCheckBox.IsChecked ?? false; 
                int userTypeId = (int)UserTypeComboBox.SelectedValue;

                if (!string.IsNullOrWhiteSpace(email) && !string.IsNullOrWhiteSpace(password) && dateOfBirth != default(DateTime))
                {
                    if (!CheckIfUserExist(email))
                    {
                        string query = $"INSERT INTO UserProfile ([password], email, user_type_id, date_of_birth, is_student) " +
                                  $"VALUES ('{password}', '{email}', {userTypeId}, '{dateOfBirth.ToString("yyyy-MM-dd")}', {Convert.ToInt32(isStudent)})";
                        dt.insertData(query);
                        SessionManager.CurrentUser = SessionManager.getUserByEmail(email);
                        await new ContentDialog1("User created successfully").ShowAsync();
                        
                        Frame.Navigate(typeof(AccountHome));
                    }
                    else
                    {
                        await new ContentDialog1("Email in use").ShowAsync();
                    }
                   
                }
                else
                {
                    await new ContentDialog1("Invalid data").ShowAsync();
                }
            }
            catch (Exception ex)
            {
                await new ContentDialog1(ex.Message).ShowAsync();
            }
        }
     
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(index));
        }
    }
}
