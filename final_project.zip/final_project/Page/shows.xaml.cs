﻿using final_project.Classes;
using final_project.Database;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using System.Data.SqlClient;
using Windows.UI.Xaml.Navigation;
using System.Collections;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace final_project.Page
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class shows { 
        public Theatre selectedTheatre { get; set; }
        public Movie selectedMovie { get; set; }
        public List<Show> showList;
        public shows()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            DatabaseAccess dt = new DatabaseAccess();
            string query = "SELECT * FROM Show;";
            string message = "There are no shows.";
            if (e.Parameter is Theatre theatre)
            {
                selectedTheatre = theatre;
                message = "There are no shows for that theatre.";
                if (selectedTheatre != null)
                    query = "SELECT * FROM Show where location_id =" + theatre.location_id+";";
            }
            if (e.Parameter is Movie movie)
            {
                selectedMovie = movie;
                message = "There are no shows for that movie.";
                if (selectedMovie != null)
                    query = "SELECT * FROM Show where movie_id =" + movie.movie_id + ";";
            }

            showList = Show.ConvertDataTableShowList(dt.SelectData(query));

            NoShowsMessage.Text = message;
            if(showList.Count > 0)
                NoShowsMessage.Visibility = Visibility.Collapsed;
            else
                NoShowsMessage.Visibility = Visibility.Visible;
        }
        private void showListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (showListView.SelectedItem is Show selectedShow)
            {
                Frame.Navigate(typeof(reservation), selectedShow);
            }
        }
    }

}
