﻿using final_project.Classes;
using final_project.Database;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace final_project.Page
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AccountHome 
    {
        List<Ticket> tickets = new List<Ticket>();
        List<Movie> movies = new List<Movie>();
        List<Theatre> theatres = new List<Theatre>();
        List<Show> shows = new List<Show>();    
        User user;
        
        public AccountHome()
        {
            if (SessionManager.IsUserLoggedIn)
            {
                user = SessionManager.CurrentUser;
            }
            else
            {
                Frame.Navigate(typeof(index));
            }
            this.InitializeComponent();
            if (user.user_type_id == 1)
                adminOption.Visibility = Visibility.Visible;

            LoadData();
        }
        public void LoadData()
        {
            // tickets
            int id = user.user_id;
            string query = "Select * from Ticket where user_id ="+id+";";
            tickets = Ticket.ConvertDataTableTicketList(DatabaseManager.dt.SelectData(query));
            // show
            string query1 = "SELECT * FROM Movie;";
            movies = Movie.ConvertDataTableToMoviesList(DatabaseManager.dt.SelectData(query1));
            // movies
            string query2 = "SELECT * FROM Show;";
            shows = Show.ConvertDataTableShowList(DatabaseManager.dt.SelectData(query2));
            // theather
            string query3 = "SELECT * FROM Theatre;";
            theatres = Theatre.ConvertDataTableToTheatresList(DatabaseManager.dt.SelectData(query3));

            locationComboBox.ItemsSource = theatres;
            movieComboBox.ItemsSource = movies;
            if(tickets.Count > 0)
                NoTicketsMessage.Visibility = Visibility.Collapsed;
            else
                NoTicketsMessage.Visibility = Visibility.Visible;
        }
        private async void CreateTheaterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string locationName = theater_location.Text.Trim();
                string locationAddress = theater_address.Text.Trim();
                string locationPhone = theater_phone.Text.Trim();
                string businessHours = theater_hours.Text.Trim();
                if (!string.IsNullOrWhiteSpace(locationName) &&
                    !string.IsNullOrWhiteSpace(locationAddress) &&
                    !string.IsNullOrWhiteSpace(locationPhone) &&
                    !string.IsNullOrWhiteSpace(businessHours))
                {
                    
                    string query = $"INSERT INTO Theatre (location_name, location_address, location_phone, location_photo, business_hours) " +
                                   $"VALUES ('{locationName}', '{locationAddress}', '{locationPhone}', 'ms-appx:///Assets/default-cinema.jpg', '{businessHours}')";
                    DatabaseManager.dt.insertData(query);
                    LoadData();
                    await new ContentDialog1("Theater created successfully").ShowAsync();
                }
                else
                {
                    await new ContentDialog1("Invalid data").ShowAsync();
                }
            }
            catch (Exception ex)
            {
                await new ContentDialog1(ex.Message).ShowAsync();
            }
        }


        private async void CreateMovieButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string movieTitle = movie_title.Text.Trim();
                string directorName = movie_director.Text.Trim();
                int duration = 0;

             
                if (!string.IsNullOrWhiteSpace(movie_duration.Text) && int.TryParse(movie_duration.Text, out duration) && duration > 0)
                {
                    string query = $"INSERT INTO Movie (movie_title, duration, director_name, photo_url) " +
                                   $"VALUES ('{movieTitle}', {duration}, '{directorName}', 'ms-appx:///Assets/default-movie.png')";
                    DatabaseManager.dt.insertData(query);
                    LoadData();
                    await new ContentDialog1("Movie created successfully").ShowAsync();
                }
                else
                {
                   
                    await new ContentDialog1("Invalid duration").ShowAsync();
                }
            }
            catch (Exception ex)
            {
               
                await new ContentDialog1(ex.Message).ShowAsync();
            }
        }

        private void UpdateShowButton_Click(object sender, RoutedEventArgs e)
        {
            locationComboBox.Visibility = Visibility.Collapsed;
            movieComboBox.Visibility = Visibility.Collapsed;
            show_inputs.Visibility = Visibility.Visible;
            ShowSelectionComboBox.ItemsSource = shows; 
            ShowSelectionComboBox.Visibility = Visibility.Visible;
            Update_show.Visibility = Visibility.Visible;
            Create_show.Visibility = Visibility.Collapsed;
            Delete_show.Visibility = Visibility.Collapsed;
            ShowSelectionComboBox.SelectionChanged += ShowSelectionComboBox_SelectionChanged;
        }

        private void DeleteShowButton_Click(object sender, RoutedEventArgs e)
        {
            show_inputs.Visibility = Visibility.Collapsed;
            ShowSelectionComboBox.ItemsSource = shows;
            ShowSelectionComboBox.Visibility = Visibility.Visible;
            Update_show.Visibility = Visibility.Collapsed;
            Create_show.Visibility = Visibility.Collapsed;
            Delete_show.Visibility = Visibility.Visible;
            ShowSelectionComboBox.SelectionChanged += ShowSelectionComboBox_SelectionChanged;
        }

        private void CreateShowButton_Click(object sender, RoutedEventArgs e)
        {
            locationComboBox.Visibility = Visibility.Visible;
            movieComboBox.Visibility = Visibility.Visible;
            show_inputs.Visibility = Visibility.Visible;
            ShowSelectionComboBox.Visibility = Visibility.Collapsed;
            Update_show.Visibility = Visibility.Collapsed;
            Create_show.Visibility = Visibility.Visible;
            Delete_show.Visibility = Visibility.Collapsed;
            ShowSelectionComboBox.SelectionChanged += ShowSelectionComboBox_SelectionChanged;
        }



        private void ShowSelectionComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          
            if (ShowSelectionComboBox.SelectedItem != null)
            {
             
                Show selectedShow = ShowSelectionComboBox.SelectedItem as Show;

                if (selectedShow != null)
                {
                    
                    ShowAvailableSeatsTextBox.Text = selectedShow.available_seats.ToString();
                    ShowDatePicker.Date = selectedShow.date_time;
                }
            }
        }

        private async void Create_show_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int locationId = (locationComboBox.SelectedItem as Theatre)?.location_id ?? 0;
                int movieId = (movieComboBox.SelectedItem as Movie)?.movie_id ?? 0;
                int availableSeats = 0;

                if (!string.IsNullOrWhiteSpace(ShowAvailableSeatsTextBox.Text) && int.TryParse(ShowAvailableSeatsTextBox.Text, out availableSeats) && availableSeats > 0)
                {
                    DateTime selectedDate = ShowDatePicker.Date.Date;
                    string formattedDate = selectedDate.ToString("yyyy-MM-dd HH:mm:ss");

                    string query = $"INSERT INTO Show (location_id, movie_id, available_seats, date_time) " +
                                   $"VALUES ({locationId}, {movieId}, {availableSeats}, '{formattedDate}')";
                    DatabaseManager.dt.insertData(query);
                    LoadData();
                    await new ContentDialog1("Show created successfully").ShowAsync();
                }
                else
                {
                    await new ContentDialog1("Invalid data").ShowAsync();
                }
            }
            catch (Exception ex)
            {
                await new ContentDialog1(ex.Message).ShowAsync();
            }
        }

        private async void Update_show_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int selectedShowId = (ShowSelectionComboBox.SelectedItem as Show)?.show_id ?? 0;
                int availableSeats = 0;

                if (selectedShowId != 0 && !string.IsNullOrWhiteSpace(ShowAvailableSeatsTextBox.Text) && int.TryParse(ShowAvailableSeatsTextBox.Text, out availableSeats) && availableSeats > 0)
                {
                    DateTime selectedDate = ShowDatePicker.Date.Date;
                    string formattedDate = selectedDate.ToString("yyyy-MM-dd HH:mm:ss");

                    string query = $"UPDATE Show SET available_seats = {availableSeats}, date_time = '{formattedDate}' WHERE show_id = {selectedShowId}";

                    DatabaseManager.dt.updateData(query);
                    LoadData();
                    await new ContentDialog1("Show updated successfully").ShowAsync();
                }
                else
                {
                    await new ContentDialog1("Invalid input or no show selected").ShowAsync();
                }
            }
            catch (Exception ex)
            {
                await new ContentDialog1(ex.Message).ShowAsync();
            }
        }

        private async void Delete_show_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Show selectedShow = ShowSelectionComboBox.SelectedItem as Show;

                if (selectedShow != null)
                {
                    // delete tickets first
                    string ticketDeleteQuery = $"DELETE FROM Ticket WHERE show_id = {selectedShow.show_id}";
                    DatabaseManager.dt.deleteData(ticketDeleteQuery);
                    // delete the show
                    string query = $"DELETE FROM Show WHERE show_id = {selectedShow.show_id}";
                    DatabaseManager.dt.deleteData(query);
                    LoadData();
                    await new ContentDialog1("Show deleted successfully").ShowAsync();
                }
                else
                {
                    await new ContentDialog1("No show selected").ShowAsync();
                }
            }
            catch (Exception ex)
            {
                await new ContentDialog1(ex.Message).ShowAsync();
            }
        }

   


        private void AdminComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            ComboBox comboBox = sender as ComboBox;
            ComboBoxItem selectedItem = comboBox.SelectedItem as ComboBoxItem;

            if (selectedItem != null)
            {
                string selectedOption = selectedItem.Content.ToString();
                switch (selectedOption)
                {
                    case "Theater":
                        TheaterInputs.Visibility = Visibility.Visible;
                        MovieInputs.Visibility = Visibility.Collapsed;
                        ShowInputs.Visibility = Visibility.Collapsed;
                        break;
                    case "Show":
                     
                        TheaterInputs.Visibility = Visibility.Collapsed;
                        MovieInputs.Visibility = Visibility.Collapsed;
                        ShowInputs.Visibility = Visibility.Visible;
                        break;
                    case "Movie":

                        TheaterInputs.Visibility = Visibility.Collapsed;
                        MovieInputs.Visibility = Visibility.Visible;
                        ShowInputs.Visibility = Visibility.Collapsed;
                        break;
                    default:
                       
                        TheaterInputs.Visibility = Visibility.Visible;
                        MovieInputs.Visibility = Visibility.Collapsed;
                        ShowInputs.Visibility = Visibility.Collapsed;
                        break;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SessionManager.CurrentUser = null;
            Frame.Navigate(typeof(index));
        }
    }
}
