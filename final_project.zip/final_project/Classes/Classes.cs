﻿using final_project.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;

namespace final_project.Classes
{
    // Class UserType
    public class UserType
    {
        public int user_type_id { get; set; }
        public string user_type_name { get; set; }
        public static List<UserType> ConvertDataTableUserTypeList(DataTable dataTable)
        {
            List<UserType> userTypeList = new List<UserType>();
            foreach (DataRow row in dataTable.Rows)
            {
                UserType userType = new UserType
                {
                    user_type_id = Convert.ToInt32(row["user_type_id"]),
                    user_type_name = row["user_type_name"].ToString()
                };
                userTypeList.Add(userType);
            }
            return userTypeList;
        }
    }

    // Class User 
    public class User
    {
        public int user_id { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public int user_type_id { get; set; }
        public DateTime date_of_birth { get; set; }
        public bool is_student { get; set; }
        public static List<User> ConvertDataTableUserList(DataTable dataTable)
        {
            List<User> userList = new List<User>();

            foreach (DataRow row in dataTable.Rows)
            {
                User user = new User
                {
                    user_id = Convert.ToInt32(row["user_id"]),
                    password = row["password"].ToString(),
                    email = row["email"].ToString(),
                    user_type_id = Convert.ToInt32(row["user_type_id"]),
                    date_of_birth = Convert.ToDateTime(row["date_of_birth"]),
                    is_student = Convert.ToBoolean(row["is_student"])
                };

                userList.Add(user);
            }

            return userList;
        }
    }

    // Class Theatre 
    public class Theatre
    {
        public int location_id { get; set; }
        public string location_name { get; set; }
        public string location_address { get; set; }
        public string location_phone { get; set; }
        public string location_photo { get; set; }
        public string business_hours { get; set; }

        public static List<Theatre> ConvertDataTableToTheatresList(DataTable dataTable)
        {
            List<Theatre> theatresList = new List<Theatre>();

            foreach (DataRow row in dataTable.Rows)
            {
                Theatre theatre = new Theatre
                {
                    location_id = Convert.ToInt32(row["location_id"]),
                    location_name = row["location_name"].ToString(),
                    location_address = row["location_address"].ToString(),
                    location_phone = row["location_phone"].ToString(),
                    location_photo = row["location_photo"].ToString(),
                    business_hours = row["business_hours"].ToString()
                };
                theatresList.Add(theatre);
            }

            return theatresList;
        }
        public override string ToString()
        {
            return $"{location_name}" +
                   $" {location_address}"+
                   $" {location_phone}";
        }
    }

    // Class Movie 
    public class Movie
    {
        public int movie_id { get; set; }
        public string movie_title { get; set; }
        public int duration { get; set; }
        public string director_name { get; set; }
        public string photo_url { get; set; }
        public static List<Movie> ConvertDataTableToMoviesList(DataTable dataTable)
        {
            List<Movie> moviesList = new List<Movie>();

            foreach (DataRow row in dataTable.Rows)
            {
                Movie movie = new Movie
                {
                    movie_id = Convert.ToInt32(row["movie_id"]),
                    movie_title = row["movie_title"].ToString(),
                    duration = Convert.ToInt32(row["duration"]),
                    director_name = row["director_name"].ToString(),
                    photo_url = row["photo_url"].ToString()
                };

                moviesList.Add(movie);
            }

            return moviesList;
        }
        public override string ToString()
        {
            return $"{movie_title}" +
                   $" {duration} minutes" +
                   $" {director_name}";
        }
    }

    // Class Show 
    public class Show
    {
        public int show_id { get; set; }
        public int location_id { get; set; }
        public int movie_id { get; set; }
        public int available_seats { get; set; }
        public DateTime date_time { get; set; }

        public string getMovieTitle(List<Movie> movies)
        {
            String movieTitle = null;
            movies.ForEach((movie) =>
            {
                if (movie_id == movie.movie_id)
                   movieTitle = movie.movie_title;
            });
            return movieTitle;
        }
        public string getLocationName(List<Theatre> theatres)
        {
            String locationName = null;
            theatres.ForEach((theatre) =>
            {
                if (location_id == theatre.location_id)
                    locationName = theatre.location_name;
            });
            return locationName;
        }

        public static List<Show> ConvertDataTableShowList(DataTable dataTable)
        {
            List<Show> showList = new List<Show>();

            foreach (DataRow row in dataTable.Rows)
            {
                Show show = new Show
                {
                    show_id = Convert.ToInt32(row["show_id"]),
                    location_id = Convert.ToInt32(row["location_id"]),
                    movie_id = Convert.ToInt32(row["movie_id"]),
                    available_seats = Convert.ToInt32(row["available_seats"]),
                    date_time = Convert.ToDateTime(row["date_time"])
                };
                showList.Add(show);
            }
            return showList;
        }
        public override string ToString()
        {
            return $"Id: {show_id}," +
                   $"Location: {location_id}," +
                   $"Movie: {movie_id},"+
                   $"Available: {available_seats}," +
                   $"Date: {date_time}" ;
        }
    }
    // Class Ticket 
    public class Ticket
    {
        public int ticket_id { get; set; }
        public int user_id { get; set; }
        public int show_id { get; set; }
        public int quantity { get; set; }
        public decimal price { get; set; }
        public DateTime order_date { get; set; }
        public decimal amount { get; set; }
        public static List<Ticket> ConvertDataTableTicketList(DataTable dataTable)
        {
            List<Ticket> ticketList = new List<Ticket>();

            foreach (DataRow row in dataTable.Rows)
            {
                Ticket ticket = new Ticket
                {
                    ticket_id = Convert.ToInt32(row["ticket_id"]),
                    user_id = Convert.ToInt32(row["user_id"]),
                    show_id = Convert.ToInt32(row["show_id"]),
                    quantity = Convert.ToInt32(row["quantity"]),
                    price = Convert.ToDecimal(row["price"]),
                    order_date = Convert.ToDateTime(row["order_date"]),
                    amount = Convert.ToDecimal(row["amount"])
                };

                ticketList.Add(ticket);
            }

            return ticketList;
        }
    }
    // Class TicketPrice
    public class TicketPrice
    {
        public int location_id { get; set; }
        public decimal regular_price { get; set; }
        public decimal senior_discount { get; set; }
        public decimal student_discount { get; set; }
        public decimal member_discount { get; set; }
        public decimal admin_discount { get; set; }
        public decimal tuesday_discount { get; set; }
        public static List<TicketPrice> ConvertDataTableTicketPriceList(DataTable dataTable)
        {
            List<TicketPrice> ticketPriceList = new List<TicketPrice>();

            foreach (DataRow row in dataTable.Rows)
            {
                TicketPrice ticketPrice = new TicketPrice
                {
                    location_id = Convert.ToInt32(row["location_id"]),
                    regular_price = Convert.ToDecimal(row["regular_price"]),
                    senior_discount = Convert.ToDecimal(row["senior_discount"]),
                    student_discount = Convert.ToDecimal(row["student_discount"]),
                    member_discount = Convert.ToDecimal(row["member_discount"]),
                    admin_discount = Convert.ToDecimal(row["admin_discount"]),
                    tuesday_discount = Convert.ToDecimal(row["tuesday_discount"])
                };

                ticketPriceList.Add(ticketPrice);
            }

            return ticketPriceList;
        }
    }
    public static class SessionManager
    {
        public static User CurrentUser { get; set; } 

        public static bool IsUserLoggedIn => CurrentUser != null;

        public static User getUserByEmail(string email)
        {
            try
            {
                string query = $"SELECT * FROM UserProfile WHERE email = '{email}'";
                DataTable dataTable = new DatabaseAccess().SelectData(query);
                if (dataTable.Rows.Count > 0)
                {
                    return User.ConvertDataTableUserList(dataTable).FirstOrDefault();
                }
                else
                {
                    return null; 
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
    public static class DatabaseManager
    {
        public static DatabaseAccess dt { get; set; }

    }

}
