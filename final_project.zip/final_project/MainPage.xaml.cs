﻿using final_project.Classes;
using final_project.Database;
using final_project.Page;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace final_project
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public partial class MainPage 
    {
       
        /// <summary>
        /// DatabaseAccess methods:
        ///     insertData(string query)
        ///     updateData(string query)
        ///     deleteData(string query)
        ///     selectData(string query)
        /// </summary>
        
        public MainPage()
        {
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.Maximized;
            this.InitializeComponent();
            DatabaseManager.dt = new DatabaseAccess();
            frame.Navigate(typeof(Page.index));
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (frame.CanGoBack)
            {
                frame.GoBack();
            }
        }

        private void TicketsButton_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(typeof(Page.shows));
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            frame.Navigate(typeof(Page.cinema));
        }

        private void AccountButton_Click(object sender, RoutedEventArgs e)
        {
            if (SessionManager.IsUserLoggedIn)
            {
                frame.Navigate(typeof(Page.AccountHome));
            }
            else
            {
                frame.Navigate(typeof(Page.login));
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            frame.Navigate(typeof(Page.index));
        }
    }
}
